# Vortex Game Extension for Hardspace: Shipbreaker

This is a BepInEx extension for the Hardpsace: Shipbreaker game.